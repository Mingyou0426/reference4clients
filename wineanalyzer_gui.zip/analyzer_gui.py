import os.path

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn import ensemble, metrics

try:
    BASE_DIR = os.path.dirname(os.path.abspath(__file__))
except NameError:
    import sys
    BASE_DIR = os.path.dirname(os.path.abspath(sys.argv[0]))

# BASE_DIR = os.path.dirname(os.path.abspath(''))
# conn = sqlite3.connect('C:\\Users\\User\\Desktop\\wineanalyzer_src\\wine.db')
BASE_DIR = 'C:\\Users\\User\\Desktop\\wineanalyzer_src\\';
# db_path = os.path.join(BASE_DIR, "wine.db")

state_csv = pd.read_csv(os.path.join(BASE_DIR, "statescore.csv"))
print(state_csv.head(state_csv.shape[0]+1))
print('\n')

variety_csv = pd.read_csv(os.path.join(BASE_DIR, "varietyscore.csv"))
pd.set_option('display.max_rows', variety_csv.shape[0]+1)
print(variety_csv)
print('\n')

variety_csv = pd.read_csv(os.path.join(BASE_DIR, "varietyscore.csv"))
pd.set_option('display.max_rows', variety_csv.shape[0]+1)
print(variety_csv)

wine_csv = pd.read_csv(os.path.join(BASE_DIR, "wineout.csv"))
pd.set_option('display.max_colwidth', -1)
print(wine_csv[['title','totalscore']].head(100))