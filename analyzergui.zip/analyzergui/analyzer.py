import xlrd
import os.path
import openpyxl
import tkinter
from tkinter.filedialog import askopenfilename

BASE_DIR = os.path.dirname(os.path.abspath(''))
global db_path
db_path = os.path.join(BASE_DIR, 'testdata.xlsx')

top = tkinter.Tk()
top.title('Analyzer')
top.resizable(0, 0)
top.geometry("900x640")

label1 = tkinter.Label(top, text ='Excel file Path: ')
label1.place(x=10, y=10, width=100, height=20)
# label1.pack()
global dbpath
dbpath = tkinter.Text(top)
dbpath.place(x=120, y=10, width=400, height=20)

label4factorpercentage = tkinter.Label(top, text ='Factor Percentage', anchor='w')
label4factorpercentage.place(x=10, y=55, width=100, height=20)

label4taste = tkinter.Label(top, text ='Taste Factor Percentage: ', anchor='w')
label4taste.place(x=10, y=80, width=200, height=20)
label4clean = tkinter.Label(top, text ='Clean Factor Percentage: ', anchor='w')
label4clean.place(x=10, y=100, width=200, height=20)
label4atmo = tkinter.Label(top, text ='Atomosphere Factor Percentage: ', anchor='w')
label4atmo.place(x=10, y=120, width=200, height=20)
label4location = tkinter.Label(top, text ='Location Factor Percentage: ', anchor='w')
label4location.place(x=10, y=140, width=200, height=20)
label4price = tkinter.Label(top, text ='Price Factor Percentage: ', anchor='w')
label4price.place(x=10, y=160, width=200, height=20)
label4result1 = tkinter.Label(top, text ='', anchor='w')
label4result1.place(x=10, y=180, width=400, height=20)

label4seasonal = tkinter.Label(top, text ='Seasonal Percentage: ', anchor='w')
label4seasonal.place(x=10, y=220, width=200, height=20)
label4rating = [tkinter.Label(top, text ='Rating 1: ', anchor='w'),
                tkinter.Label(top, text='Rating 2: ', anchor='w'),
                tkinter.Label(top, text='Rating 3: ', anchor='w'),
                tkinter.Label(top, text='Rating 4: ', anchor='w'),
                tkinter.Label(top, text='Rating 5: ', anchor='w')]
label4rating[0].place(x=10, y=240, width=200, height=20)
label4rating[1].place(x=10, y=260, width=200, height=20)
label4rating[2].place(x=10, y=280, width=200, height=20)
label4rating[3].place(x=10, y=300, width=200, height=20)
label4rating[4].place(x=10, y=320, width=200, height=20)
label4result2 = tkinter.Label(top, text ='', anchor='w')
label4result2.place(x=10, y=340, width=300, height=20)

label4useful = tkinter.Label(top, text ='Comments having best number of useful', anchor='w')
label4useful.place(x=10, y=360, width=300, height=20)

txt4useful = tkinter.Text(top)
scrollb4useful = tkinter.Scrollbar(top, command = txt4useful.yview)
txt4useful['yscroll'] = scrollb4useful.set
txt4useful.place(x=10, y=380, width=400, height=100)
scrollb4useful.place(x=410, y=380, width=15, height=100)
scrollb4useful.config(command=txt4useful.yview)

label4funny = tkinter.Label(top, text ='Comments having best number of funny', anchor='w')
label4funny.place(x=10, y=500, width=300, height=20)

txt4funny = tkinter.Text(top)
scrollb4funny = tkinter.Scrollbar(top, command=txt4funny.yview)
txt4funny['yscroll'] = scrollb4funny.set
txt4funny.place(x=10, y=520, width=400, height=100)
scrollb4funny.place(x=410, y=520, width=15, height=100)
scrollb4funny.config(command=txt4funny.yview)

label4cool = tkinter.Label(top, text ='Comments having best number of cool', anchor='w')
label4cool.place(x=450, y=55, width=300, height=20)

txt4cool = tkinter.Text(top)
scrollb4cool = tkinter.Scrollbar(top, command=txt4cool.yview)
txt4cool['yscroll'] = scrollb4cool.set
txt4cool.place(x=450, y=75, width=400, height=250)
scrollb4cool.place(x=850, y=75, width=15, height=250)
scrollb4cool.config(command=txt4cool.yview)

label4reviews = tkinter.Label(top, text ='Comments having best number of reviews', anchor='w')
label4reviews.place(x=450, y=335, width=300, height=20)

txt4reviews = tkinter.Text(top)
scrollb4reviews = tkinter.Scrollbar(top, command=txt4reviews.yview)
txt4reviews['yscroll'] = scrollb4reviews.set
txt4reviews.place(x=450, y=355, width=400, height=250)
scrollb4reviews.place(x=850, y=355, width=15, height=250)
scrollb4reviews.config(command=txt4reviews.yview)

def startBrowse():
    db_path = askopenfilename(filetypes=(("Excel files", "*.xlsx;*.xls"),
                                  ("All files", "*.*")))
    print(db_path)
    dbpath.delete("1.0")
    dbpath.insert("1.0", db_path)

browse = tkinter.Button(top, text = "Browse", command = startBrowse)
browse.place(x=550, y=10)

def startAnalyze():
    wb = openpyxl.load_workbook(db_path)
    wb.active
    sheet = wb.worksheets[0]

    sheet.column_dimensions.group('A')

    print(sheet['A1'].value)

    row_count = sheet.max_row - 1
    print(row_count)

    ratings = {}
    rowcnt4rest = {}

    i = 0
    for row in sheet.rows:
        if i == 0:
            i += 1
            continue
        if ratings.get(row[0].value) is None:
            ratings[row[0].value] = row[4].value
            rowcnt4rest[row[0].value] = 1
        else:
            ratings[row[0].value] += row[4].value
            rowcnt4rest[row[0].value] += 1

    upratings = []
    ratings[1] = ratings[1] / rowcnt4rest[1]
    for ratkey in ratings.keys():
        if ratkey != 1:
            ratings[ratkey] = ratings[ratkey] / rowcnt4rest[ratkey]
        print(ratings[ratkey])
        if ratings[ratkey] > ratings[1]:
            upratings.append(ratkey)

    print('Restaurant count having bigger rate: ', len(upratings))

    i = 0
    tastecount1 = 0
    cleancount1 = 0
    atmocount1 = 0
    loccount1 = 0
    pricecount1 = 0
    totcount1 = 0

    reviewcontent = ''
    for row in sheet.rows:
        if i == 0:
            i += 1
            continue
        if row[0].value == 1:
            totcount1 += 1
            reviewcontent = row[9].value
            if reviewcontent is not None:
                tastecount1 += reviewcontent.count('delicious')
                tastecount1 += reviewcontent.count('juicy')
                cleancount1 += reviewcontent.count('clean')
                atmocount1 += reviewcontent.count('atmosphere')
                loccount1 += reviewcontent.count('location')
                loccount1 += reviewcontent.count('place')
                pricecount1 += reviewcontent.count('price')
                pricecount1 += reviewcontent.count('budget')

    print("Current restaurant factors")
    tastecount1 = tastecount1 / totcount1
    cleancount1 = cleancount1 / totcount1
    atmocount1 = atmocount1 / totcount1
    loccount1 = loccount1 / totcount1
    pricecount1 = pricecount1 / totcount1
    # seascount1 = seascount1/totcount
    print('1', tastecount1, cleancount1, atmocount1, loccount1, pricecount1)

    uptaste = 0
    upclean = 0
    upatmo = 0
    uploc = 0
    upprice = 0
    for uprating in upratings:
        tastecount = 0
        cleancount = 0
        atmocount = 0
        loccount = 0
        pricecount = 0
        totcount = 0
        for row in sheet.rows:
            if row[0].value == uprating:
                totcount += 1
                reviewcontent = row[9].value
                if reviewcontent is not None:
                    tastecount += reviewcontent.count('delicious')
                    tastecount += reviewcontent.count('juicy')
                    cleancount += reviewcontent.count('clean')
                    atmocount += reviewcontent.count('atmosphere')
                    loccount += reviewcontent.count('location')
                    loccount += reviewcontent.count('place')
                    pricecount += reviewcontent.count('price')
                    pricecount += reviewcontent.count('budget')
        tastecount = tastecount / totcount
        cleancount = cleancount / totcount
        atmocount = atmocount / totcount
        loccount = loccount / totcount
        pricecount = pricecount / totcount

        print(uprating, tastecount, cleancount, atmocount, loccount, pricecount)
        if tastecount > tastecount1:
            uptaste += 1
        if cleancount > cleancount1:
            upclean += 1
        if atmocount > atmocount1:
            upatmo += 1
        if loccount > loccount1:
            uploc += 1
        if pricecount > pricecount1:
            upprice += 1

    upcount = len(upratings)
    print("")
    print("Factor Percentage")
    print("Taste Percentage: ", format(uptaste / upcount * 100, '.2f'), '%')
    label4taste.config(text="Taste Factor Percentage: " + format(uptaste / upcount * 100, '.2f') + "%")
    print("Clean Percentage: ", format(upclean / upcount * 100, '.2f'), '%')
    label4clean.config(text="Clean Factor Percentage: " + format(upclean / upcount * 100, '.2f') + "%")
    print("Atmosphere Percentage: ", format(upatmo / upcount * 100, '.2f'), '%')
    label4atmo.config(text="Atmosphere Factor Percentage: " + format(upatmo / upcount * 100, '.2f') + "%")
    print("Location Percentage: ", format(uploc / upcount * 100, '.2f'), '%')
    label4location.config(text="Location Factor Percentage: " + format(uploc / upcount * 100, '.2f') + "%")
    print("Price Percentage: ", format(upprice / upcount * 100, '.2f'), '%')
    label4price.config(text="Price Factor Percentage: " + format(upprice / upcount * 100, '.2f') + "%")

    print("Impact order is Price, Clean, Taste, Atmosphere and the Location is the last.")
    label4result1.config(text="Impact order is Price, Clean, Taste, Atmosphere and the Location is the last.")

    book = xlrd.open_workbook(db_path)
    sheet = book.sheets()[0]
    data = [sheet.row_values(i) for i in range(sheet.nrows)]
    labels = data[0]
    data = data[1:]
    data.sort(key=lambda x: x[6], reverse=True)

    print("")
    print("Comments having best number of useful")
    txt4useful.delete("1.0")
    msg4useful = ""
    for i in range(0, 10):
        print("")
        print(data[i][9])
        msg4useful = msg4useful + data[i][9] + "\n\n"
    txt4useful.insert("1.0", msg4useful)

    data = [sheet.row_values(i) for i in range(sheet.nrows)]
    labels = data[0]
    data = data[1:]
    data.sort(key=lambda x: x[7], reverse=True)

    print("")
    print("Comments having best number of funny")
    txt4funny.delete("1.0")
    msg4funny = ""
    for i in range(0, 10):
        print("")
        print(data[i][9])
        msg4funny = msg4funny + data[i][9] + "\n\n"
    txt4funny.insert("1.0", msg4funny)

    data = [sheet.row_values(i) for i in range(sheet.nrows)]
    labels = data[0]
    data = data[1:]
    data.sort(key=lambda x: x[8], reverse=True)

    print("")
    print("Comments having best number of cool")
    txt4cool.delete("1.0")
    msg4cool = ""
    for i in range(0, 10):
        print("")
        print(data[i][9])
        msg4cool = msg4cool + data[i][9] + "\n\n"
    txt4cool.insert("1.0", msg4cool)

    sheet = wb.worksheets[0]
    seascount = [0, 0, 0, 0, 0]
    i = 0
    for row in sheet.rows:
        if i == 0:
            i += 1
            continue
        reviewcontent = row[9].value
        if reviewcontent is not None:
            seascount[row[4].value - 1] += reviewcontent.count('season')
            seascount[row[4].value - 1] += reviewcontent.count('spring')
            seascount[row[4].value - 1] += reviewcontent.count('summer')
            seascount[row[4].value - 1] += reviewcontent.count('autumn')
            seascount[row[4].value - 1] += reviewcontent.count('winter')

    seassum = 0
    for i in range(0, 5):
        seassum += seascount[i]

    print("")
    print("Season Factor Percentage")
    for i in range(0, 5):
        label4rating[i].config(text="Rating "+format(i + 1, 'd')+": "+format(seascount[i] / seassum * 100, '.2f')+'%')
        print("Rating ", i + 1, ": ", format(seascount[i] / seassum * 100, '.2f'), '%')

    print("This shows that seasonal impact is somewhat important.")
    label4result2.config(text="This shows that seasonal impact is somewhat important.")

    sheet = book.sheets()[0]
    data = [sheet.row_values(i) for i in range(sheet.nrows)]
    labels = data[0]
    data = data[1:]
    data.sort(key=lambda x: x[3], reverse=True)

    print("")
    print("Comments having best number of reviews")
    txt4reviews.delete("1.0")
    msg4reviews = ""
    for i in range(0, 10):
        print("")
        print(data[i][9])
        msg4reviews = msg4reviews + data[i][9] + "\n\n"
    txt4reviews.insert("1.0", msg4reviews)

anasta = tkinter.Button(top, text = "Analyze", command = startAnalyze)
anasta.place(x=600, y=10)

top.mainloop()