import sqlite3
import os.path

# BASE_DIR = os.path.dirname(os.path.abspath(__file__))
BASE_DIR = os.path.dirname(os.path.abspath(''))
db_path = os.path.join(BASE_DIR, "20200415\\DINERS.db")

conn = sqlite3.connect(db_path)
cursor = conn.cursor()

cursor.execute('insert into canteen(providerid, name, location, time_open, time_closed) values(?, ?, ?, ?, ?)', (1, 'IT College Canteen', 'Tallinn', '10.00', '21.00'))

# conn.commit()

cursor.execute('select * from canteen where time_open>=? and time_open<=?', ('16.15', '18.00'))
for row in cursor:
    print(row[2], '\n')

cursor.execute('select a.* from canteen a, provider b where a.providerid=b.id and b.providername=?', ('Rahva Toit',))
for row in cursor:
    print(row[2], '\n')

conn.close()