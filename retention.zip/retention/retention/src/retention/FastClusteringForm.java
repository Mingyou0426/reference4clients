package retention;

import javax.swing.table.TableModel;
import javax.swing.GroupLayout.Alignment;
import javax.swing.GroupLayout;
import java.awt.Font;
import java.awt.Toolkit;

import javax.swing.JTextField;
import javax.swing.JLabel;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintStream;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import weka.core.Instances;
import weka.core.converters.ArffSaver;
import weka.core.converters.CSVLoader;

import java.awt.Dimension;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.SwingConstants;
import javax.swing.JTextArea;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import java.awt.Color;
import javax.swing.ImageIcon;

public class FastClusteringForm extends javax.swing.JFrame {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	File selectedTrainFile;
	File selectedTestFile;


    
    ManageRetentionForm manageretentionform;
    
    public FastClusteringForm() {
    	setTitle("Pannello di analisi Clustering veloce");
    	getContentPane().setPreferredSize(new Dimension(870, 650));
    	setResizable(false);
        initComponents();
       

        
        TrainButton = new JButton("Selezione il Training File");
        TrainButton.setBounds(5, 50, 182, 30);
        jPanel1.add(TrainButton);
        TrainButton.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		JFileChooser fileChooser = new JFileChooser();
        	    int returnValue = fileChooser.showOpenDialog(null);
        	    if (returnValue == JFileChooser.APPROVE_OPTION) {
        	    	selectedTrainFile = fileChooser.getSelectedFile();
        	    	textAreaTrainFile.setText(selectedTrainFile.toString());
        	    }
        	}
        });
        
        textAreaTrainFile = new JTextArea();
        textAreaTrainFile.setForeground(new Color(255, 255, 255));
        textAreaTrainFile.setBackground(new Color(135, 206, 250));
        textAreaTrainFile.setEditable(false);
        textAreaTrainFile.setBounds(219, 50, 383, 30);
        jPanel1.add(textAreaTrainFile);

        TestButton = new JButton("Seleziona il File Test");
        TestButton.setBounds(5, 100, 182, 30);
        jPanel1.add(TestButton);        
        TestButton.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		JFileChooser fileChooser = new JFileChooser();
        	    int returnValue = fileChooser.showOpenDialog(null);
        	    if (returnValue == JFileChooser.APPROVE_OPTION) {
        	    	selectedTestFile = fileChooser.getSelectedFile();
        	    	textAreaTestFile.setText(selectedTestFile.toString());
        	    }
        	}
        });
        
        textAreaTestFile = new JTextArea();
        textAreaTestFile.setForeground(new Color(255, 255, 255));
        textAreaTestFile.setBackground(new Color(135, 206, 250));
        textAreaTestFile.setEditable(false);
        textAreaTestFile.setBounds(219, 100, 383, 30);
        jPanel1.add(textAreaTestFile);
        
        JLabel LabelParametri = new JLabel("Numero di Cluster:");
        LabelParametri.setBounds(26, 150, 126, 20);
        jPanel1.add(LabelParametri);
        
        textFieldCluster = new JTextField();
        textFieldCluster.setForeground(new Color(255, 255, 255));
        textFieldCluster.setBackground(new Color(135, 206, 250));
        textFieldCluster.setBounds(164, 145, 57, 30);
        jPanel1.add(textFieldCluster);
        textFieldCluster.setColumns(10);
        
        JLabel LabelParametri1 = new JLabel("Ignore Field:");
        LabelParametri1.setBounds(230, 150, 80, 20);
        jPanel1.add(LabelParametri1);
        
        textFieldIgnore = new JTextField();
        textFieldIgnore.setForeground(new Color(255, 255, 255));
        textFieldIgnore.setBackground(new Color(135, 206, 250));
        textFieldIgnore.setBounds(320, 145, 57, 30);
        jPanel1.add(textFieldIgnore);
        textFieldIgnore.setColumns(10);
        
        OutputTextArea = new JTextArea();        
        OutputScrollPane = new JScrollPane();
        OutputScrollPane.setBounds(10, 180, 600, 450);
        jPanel1.add(OutputScrollPane);
        OutputScrollPane.setViewportView(OutputTextArea);
        PrintStream printStream = new PrintStream(new ChurnOutput(OutputTextArea));
                
        EvalueButton = new JButton("AVVIA CLUSTERING");
        EvalueButton.setIcon(new ImageIcon(FastClusteringForm.class.getResource("/Start-icon.png")));
        EvalueButton.setBounds(638, 188, 200, 40);
        jPanel1.add(EvalueButton);        
        EvalueButton.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		try {
        			int numcluster = Integer.parseInt(textFieldCluster.getText());
        			String ignorefield = textFieldIgnore.getText();
        			
        			clustering.clustering(selectedTrainFile, selectedTestFile,numcluster,1, ignorefield);
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
        	}
        });
        
        ActionClusterButton = new JButton("Configura RETENTION");
        ActionClusterButton.setIcon(new ImageIcon(FastClusteringForm.class.getResource("/config.png")));
        ActionClusterButton.setBackground(new Color(255, 255, 255));
        ActionClusterButton.setBounds(652, 89, 182, 40);
        jPanel1.add(ActionClusterButton);        
        
        lblNewLabel = new JLabel("");
        lblNewLabel.setIcon(new ImageIcon(FastClusteringForm.class.getResource("/datanaly.png")));
        lblNewLabel.setBounds(622, 285, 225, 236);
        jPanel1.add(lblNewLabel);
        
//        lblNewLabel_1 = new JLabel("Ignora il primo Attributo in modo predefinito: CID");
//        lblNewLabel_1.setFont(new Font("Lucida Grande", Font.ITALIC, 13));
//        lblNewLabel_1.setBounds(249, 152, 325, 16);
//        jPanel1.add(lblNewLabel_1);
        ActionClusterButton.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		try {
        			manageretentionform.setVisible(true);
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
        	}
        });
        
        System.setOut(printStream);
       // System.setErr(printStream);
        
        try {
			manageretentionform = new ManageRetentionForm();
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
   
    
    private void initComponents() {
        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel1.setForeground(new Color(255, 255, 255));
        jLabel1.setHorizontalAlignment(SwingConstants.CENTER);
        new javax.swing.JLabel();
        new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.HIDE_ON_CLOSE);

        jPanel1.setBackground(new Color(255, 255, 255));
        jPanel1.setLayout(null);

        jPanel2.setBackground(new Color(135, 206, 250));

        jLabel1.setFont(new Font("Calibri", Font.BOLD, 18)); // NOI18N
        jLabel1.setText("FAST Clustering");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2Layout.setHorizontalGroup(
        	jPanel2Layout.createParallelGroup(Alignment.TRAILING)
        		.addGroup(Alignment.LEADING, jPanel2Layout.createSequentialGroup()
        			.addGap(306)
        			.addComponent(jLabel1, GroupLayout.PREFERRED_SIZE, 294, GroupLayout.PREFERRED_SIZE)
        			.addContainerGap(300, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
        	jPanel2Layout.createParallelGroup(Alignment.LEADING)
        		.addGroup(jPanel2Layout.createSequentialGroup()
        			.addContainerGap()
        			.addComponent(jLabel1, GroupLayout.PREFERRED_SIZE, 32, GroupLayout.PREFERRED_SIZE)
        			.addContainerGap(44, Short.MAX_VALUE))
        );
        jPanel2.setLayout(jPanel2Layout);

        jPanel1.add(jPanel2);
        jPanel2.setBounds(0, 0, 900, 40);

	    javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
	    layout.setHorizontalGroup(
	    	layout.createParallelGroup(Alignment.LEADING)
	    		.addComponent(jPanel1, GroupLayout.DEFAULT_SIZE, 900, Short.MAX_VALUE)
	    );
	    layout.setVerticalGroup(
	    	layout.createParallelGroup(Alignment.LEADING)
	    		.addGroup(layout.createSequentialGroup()
	    			.addComponent(jPanel1, GroupLayout.PREFERRED_SIZE, 675, GroupLayout.PREFERRED_SIZE)
	    			.addContainerGap(125, Short.MAX_VALUE))
	    );
	    getContentPane().setLayout(layout);
	
	    pack();
	    
	    Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
	    this.setLocation(dim.width/2-this.getSize().width/2, dim.height/2-this.getSize().height/2);
    }
    
    public static boolean exportTrainToCSV(JTable tableToExport,String pathToExportTo) {
        try {
            TableModel model = tableToExport.getModel();
            FileWriter csv = new FileWriter(new File(pathToExportTo));
            int i = 0;
            int j = 0;
            for (i = 0; i < (model.getColumnCount()-1); i++) {
                csv.write(model.getColumnName(i) + ",");
            }
            csv.write(model.getColumnName(i));
            csv.write("\n");
            for (i = 0; i < model.getRowCount()*0.4; i++) {
                for (j = 0; j < model.getColumnCount()-1; j++) {
                    csv.write(model.getValueAt(i, j).toString() + ",");
                }
                csv.write(model.getValueAt(i, j).toString());
                csv.write("\n");
            }

            csv.close();
            return true;
        } catch (IOException e) {
            e.printStackTrace();
        }
        return false;
    }
   
    public static boolean exportTestToCSV(JTable tableToExport,String pathToExportTo) {
        try {

            TableModel model = tableToExport.getModel();
            FileWriter csv = new FileWriter(new File(pathToExportTo));
            int i = 0;
            int j = 0;
            for (i = 0; i < (model.getColumnCount()-1); i++) {
                csv.write(model.getColumnName(i) + ",");
            }
            csv.write(model.getColumnName(i));
            csv.write("\n");
            for (i = (int) ((model.getRowCount()*0.4)+1); i < model.getRowCount(); i++) {
                for (j = 0; j < model.getColumnCount()-1; j++) {
                    csv.write(model.getValueAt(i, j).toString() + ",");
                }
                csv.write(model.getValueAt(i, j).toString());
                csv.write("\n");
            }

            csv.close();
            return true;
            
            
        } catch (IOException e) {
            e.printStackTrace();
        }
        return false;
    }
    
    public boolean CsvTrainToArff() {
        try {
            
            // load the CSV file (input file)
            CSVLoader loader = new CSVLoader();
            String [] options = new String[1];
            options[0]="-H";
            loader.setOptions(options);

            Instances data = loader.getDataSet();
            System.out.println(data);

            // save as an  ARFF (output file)
            ArffSaver saver = new ArffSaver();
            saver.setInstances(data);
            saver.writeBatch();
            return true;
        } catch(Exception e) {
        	return false;
        }
    }
    
    public boolean CsvTestToArff() {
        try {
            // load the CSV file (input file)
            CSVLoader loader = new CSVLoader();
            String [] options = new String[1];
            options[0]="-H";
            loader.setOptions(options);

            Instances data = loader.getDataSet();
            System.out.println(data);

            // save as an  ARFF (output file)
            ArffSaver saver = new ArffSaver();
            saver.setInstances(data);
            saver.writeBatch();
            return true;
        } catch(Exception e) {
        	return false;
        } 
    }
 
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(FastClusteringForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(FastClusteringForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(FastClusteringForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(FastClusteringForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Crea e visualizza il form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                
            	new FastClusteringForm().setVisible(true);
            	//System.out.println("test");
            	
            }
        });
    }
    
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    
    private JButton TrainButton;
//    private JButton ClusteringButton;
    private JButton EvalueButton;
    private JButton ActionClusterButton;
    
    private JScrollPane OutputScrollPane;
    private JTextArea OutputTextArea;
    private JButton TestButton;
    
    private JTextArea textAreaTrainFile;
    private JTextArea textAreaTestFile;
    private JTextField textFieldCluster;
    private JLabel lblNewLabel;
    private JLabel lblNewLabel_1;
    
    private JTextField textFieldIgnore;
}
