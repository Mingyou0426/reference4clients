package retention;

import weka.associations.Apriori;
import weka.core.Instances;
import weka.core.converters.ConverterUtils.DataSource;

public class AprioriRule {
	Instances Regole = null;
	Apriori apriori;
	public void loadArff(String arffInput){
		DataSource source = null;
		try {
			source = new DataSource(arffInput);
			Regole = source.getDataSet();
		} catch (Exception e1) {
		}
	}
	public void generateRule(double deltaValue, double lowerBoundMinSupportValue, double minMetricValue
			, int numRulesValue, int numClassValue, double upperBoundMinSupportValue){
//valori di default
//		double deltaValue = 0.05; 
//		double lowerBoundMinSupportValue = 0.3; 
//		double minMetricValue = 0.5; 
//		int numRulesValue = 10; 
//		int numClassValue = 11;
//		double upperBoundMinSupportValue = 1.0;
		
		apriori = new Apriori();
		try {
			
			apriori.setClassIndex(numClassValue);
			apriori.setDelta(deltaValue); 
			apriori.setLowerBoundMinSupport(lowerBoundMinSupportValue); 
			apriori.setNumRules(numRulesValue); 
			apriori.setUpperBoundMinSupport(upperBoundMinSupportValue); 
			apriori.setMinMetric(minMetricValue);
			apriori.buildAssociations(Regole);
			System.out.println(apriori);
		} catch (Exception e) {
		}
	}
//	

}
