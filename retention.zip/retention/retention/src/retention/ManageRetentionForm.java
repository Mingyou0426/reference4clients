package retention;

import javax.swing.table.DefaultTableModel;
import javax.swing.GroupLayout.Alignment;
import javax.swing.GroupLayout;
import javax.swing.JTextField;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.JLabel;
import javax.swing.JScrollPane;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JButton;
import javax.swing.JTable;
import javax.swing.border.BevelBorder;
import java.awt.Color;
import java.awt.Font;

public class ManageRetentionForm extends javax.swing.JFrame {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	String [] columnNames = {"Cluster Number", "Retention"};
	String [][] data4Table = {};
    
    public ManageRetentionForm() throws SQLException {
    	setBackground(new Color(47, 79, 79));
    	setTitle("Imposta azioni di retention per ciascun cluster");
    	getContentPane().setPreferredSize(new Dimension(450, 450));
    	setResizable(false);
        initComponents();
       

        
        InsertButton = new JButton("Aggiungi Cluster");
        InsertButton.setBounds(20, 340, 130, 30);
        jPanel1.add(InsertButton);
        InsertButton.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {                
        		Connection con = clustering.getConnection();
        		Statement stmt;
        		try {
					stmt = con.createStatement();
	        		String query = "insert into datacluster(clusterid, azione) values("+maxid+", '"+tfClusterAction.getText()+"')";
	        		
	        		stmt.executeUpdate(query);
	        		
	        		if ( stmt!=null ) stmt.close();
	        		if ( con!=null ) con.close();
	        		
	        		reloadTable();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
        	}
        });
        
        ModifyButton = new JButton("Modifica Cluster");
        ModifyButton.setBounds(147, 340, 130, 30);
        jPanel1.add(ModifyButton);        
        ModifyButton.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		Connection con = clustering.getConnection();
        		Statement stmt;
        		try {
					stmt = con.createStatement();
	        		String query = "update datacluster set azione='"+tfClusterAction.getText()+"' where clusterid="+tfClusterNumber.getText();
	        		
	        		stmt.executeUpdate(query);
	        		
	        		if ( stmt!=null ) stmt.close();
	        		if ( con!=null ) con.close();
	        		
	        		reloadTable();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
        	}
        });
        
        DeleteButton = new JButton("Cancella Cluster");
        DeleteButton.setBounds(20, 394, 130, 30);
        jPanel1.add(DeleteButton);        
        DeleteButton.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		Connection con = clustering.getConnection();
        		Statement stmt;
        		try {
					stmt = con.createStatement();
	        		String query = "delete from datacluster where clusterid="+tfClusterNumber.getText();
	        		
	        		stmt.executeUpdate(query);
	        		
	        		if ( stmt!=null ) stmt.close();
	        		if ( con!=null ) con.close();
	        		
	        		reloadTable();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
        	}
        });
        
        UpdateButton = new JButton("Aggiorna Tabella");
        UpdateButton.setBounds(147, 394, 130, 30);
        jPanel1.add(UpdateButton);        
        UpdateButton.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		try {
					reloadTable();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
        	}
        });
        
        ClearButton = new JButton("Cancella Tutto");
        ClearButton.setBounds(293, 365, 117, 30);
        jPanel1.add(ClearButton);        
        ClearButton.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		tfClusterNumber.setText("");
        		tfClusterAction.setText("");
        	}
        });
        
        JLabel lblClusterNumber = new JLabel("CLUSTER numero:");
        lblClusterNumber.setForeground(new Color(255, 255, 255));
        lblClusterNumber.setFont(new Font("Lucida Grande", Font.BOLD, 13));
        lblClusterNumber.setBounds(17, 30, 130, 20);
        jPanel1.add(lblClusterNumber);
        
        tfClusterNumber = new JTextField();
        tfClusterNumber.setBounds(143, 25, 56, 30);
        tfClusterNumber.setEnabled(false);
        jPanel1.add(tfClusterNumber);
        tfClusterNumber.setColumns(10);
        
        JLabel lblClusterAction = new JLabel("Imposta AZIONE:");
        lblClusterAction.setForeground(new Color(255, 255, 255));
        lblClusterAction.setFont(new Font("Lucida Grande", Font.BOLD, 13));
        lblClusterAction.setBounds(20, 72, 117, 20);
        jPanel1.add(lblClusterAction);
        
        tfClusterAction = new JTextField();
        tfClusterAction.setBounds(140, 67, 270, 30);
        jPanel1.add(tfClusterAction);
        tfClusterAction.setColumns(10);
        
        model = new DefaultTableModel();
        model.setColumnIdentifiers(columnNames);
        tClusterList = new JTable();
        tClusterList.setModel(model);
        sp = new JScrollPane(tClusterList);
        sp.setBounds(20, 128, 400, 200);
        jPanel1.add(sp);
        
		tClusterList.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
		    @Override
		    public void valueChanged(ListSelectionEvent event) {
		        if (tClusterList.getSelectedRow() > -1) {
		            selectedRow = tClusterList.getSelectedRow(); 
		            tfClusterNumber.setText(tClusterList.getValueAt(tClusterList.getSelectedRow(), 0).toString());
		            tfClusterAction.setText(tClusterList.getValueAt(tClusterList.getSelectedRow(), 1).toString());
		        }
		    }
		});
//        this.add(jPanel1, BorderLayout.CENTER);
		
        reloadTable();
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     * @throws SQLException 
     */
   
    private void reloadTable() throws SQLException {
    	int rowCnt = model.getRowCount();

		for (int i = rowCnt - 1; i >= 0; i--) {
			model.removeRow(i);
		}
    	
        Connection con = clustering.getConnection();
		Statement stmt;
		stmt = con.createStatement();
		String query = "select * from datacluster order by clusterid";
		maxid = 0;
		ResultSet rs = stmt.executeQuery(query);
		
		while (rs.next()) {
			maxid = rs.getInt("clusterid");
			model.addRow(new Object[] {maxid, rs.getString("azione")});
		}
		maxid++;
		
		if ( rs!=null ) rs.close();
		if ( stmt!=null ) stmt.close();
		if ( con!=null ) con.close();
		
		tfClusterNumber.setText("");
		tfClusterAction.setText("");
    }
    
    private void initComponents() {
        jPanel1 = new javax.swing.JPanel();
        jPanel1.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));


        setDefaultCloseOperation(javax.swing.WindowConstants.HIDE_ON_CLOSE);

        jPanel1.setBackground(new Color(47, 79, 79));
//        jPanel1.setBounds(0,0,900,650);
        jPanel1.setLayout(null);

	    javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
	    layout.setHorizontalGroup(
	    	layout.createParallelGroup(Alignment.LEADING)
	    		.addComponent(jPanel1, GroupLayout.DEFAULT_SIZE, 450, Short.MAX_VALUE)
	    );
	    layout.setVerticalGroup(
	    	layout.createParallelGroup(Alignment.LEADING)
	    		.addGroup(layout.createSequentialGroup()
	    			.addComponent(jPanel1, GroupLayout.PREFERRED_SIZE, 675, GroupLayout.PREFERRED_SIZE)
	    			.addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
	    );
	    getContentPane().setLayout(layout);
        
//        this.add(jPanel1, BorderLayout.CENTER);
	
	    pack();
	    
	    Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
	    this.setLocation(dim.width/2-this.getSize().width/2, dim.height/2-this.getSize().height/2);
    }
 
    /**
     * @param args the command line arguments
     */

    
    private javax.swing.JPanel jPanel1;
    
    private JButton InsertButton;
    private JButton ModifyButton;
    private JButton DeleteButton;
    private JButton UpdateButton;
    private JButton ClearButton;
    
    private JTextField tfClusterNumber;
    private JTextField tfClusterAction;
    
    JTable tClusterList;
    JScrollPane sp;
    DefaultTableModel model;
    int maxid = 0;
    int selectedRow = -1;
}
