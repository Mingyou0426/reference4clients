package retention;

import javax.swing.table.TableModel;
import javax.swing.GroupLayout.Alignment;
import javax.swing.GroupLayout;
import java.awt.Font;
import java.awt.Toolkit;

import javax.swing.JTextField;
import javax.swing.JLabel;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintStream;

import java.awt.Dimension;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.SwingConstants;
import javax.swing.JTextArea;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JScrollPane;
import javax.swing.JTable;


public class ApriorForm3 extends javax.swing.JFrame {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	/**
     * Genera un nuovo form: ManageLezioniForm
     */
	File selectedTestFile;
    
    String pathTest = "E:\\ming\\angelod\\testdata\\datasetok-test.csv";
    
    public ApriorForm3() {
    	setTitle("APRIOR");
    	getContentPane().setPreferredSize(new Dimension(700, 650));
    	setResizable(false);
        initComponents(); 

        TestButton = new JButton("Select Test File");
        TestButton.setBounds(25, 50, 130, 30);
        jPanel1.add(TestButton);        
        TestButton.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		JFileChooser fileChooser = new JFileChooser();
        	    int returnValue = fileChooser.showOpenDialog(null);
        	    if (returnValue == JFileChooser.APPROVE_OPTION) {
        	    	selectedTestFile = fileChooser.getSelectedFile();
        	    	textAreaTestFile.setText(selectedTestFile.toString());
        	    }
        	}
        });
        
        AprioriRule weka = new AprioriRule();
        
        textAreaTestFile = new JTextArea();
        textAreaTestFile.setEditable(false);
        textAreaTestFile.setBounds(160, 50, 500, 30);
        jPanel1.add(textAreaTestFile);
        
        JLabel LabelParametri = new JLabel("Delta Value", SwingConstants.RIGHT);
        LabelParametri.setBounds(30, 95, 150, 20);
        jPanel1.add(LabelParametri);
        
        textFieldDelta = new JTextField();
        textFieldDelta.setBounds(190, 90, 200, 30);
        jPanel1.add(textFieldDelta);
        textFieldDelta.setColumns(10);
        textFieldDelta.setText("0.05");
        
        JLabel LabelParametri2 = new JLabel("Lower Bound Min Support", SwingConstants.RIGHT);
        LabelParametri2.setBounds(30, 125, 150, 20);
        jPanel1.add(LabelParametri2);
        
        textFieldlowerBoundMinSupport = new JTextField();
        textFieldlowerBoundMinSupport.setBounds(190, 120, 200, 30);
        jPanel1.add(textFieldlowerBoundMinSupport);
        textFieldlowerBoundMinSupport.setColumns(10);
        textFieldlowerBoundMinSupport.setText("0.3");
        
        JLabel LabelParametri3 = new JLabel("Min Metric", SwingConstants.RIGHT);
        LabelParametri3.setBounds(30, 155, 150, 20);
        jPanel1.add(LabelParametri3);
        
        textFieldminMetric = new JTextField();
        textFieldminMetric.setBounds(190, 150, 200, 30);
        jPanel1.add(textFieldminMetric);
        textFieldminMetric.setColumns(10);
        textFieldminMetric.setText("0.5");
        
        JLabel LabelParametri4 = new JLabel("Num Rules", SwingConstants.RIGHT);
        LabelParametri4.setBounds(30, 185, 150, 20);
        jPanel1.add(LabelParametri4);
        
        textFieldnumRules = new JTextField();
        textFieldnumRules.setBounds(190, 180, 200, 30);
        jPanel1.add(textFieldnumRules);
        textFieldnumRules.setColumns(10);
        textFieldnumRules.setText("10");
        
        JLabel LabelParametri5 = new JLabel("Num Class", SwingConstants.RIGHT);
        LabelParametri5.setBounds(30, 215, 150, 20);
        jPanel1.add(LabelParametri5);
        
        textFieldnumClass = new JTextField();
        textFieldnumClass.setBounds(190, 210, 200, 30);
        jPanel1.add(textFieldnumClass);
        textFieldnumClass.setColumns(10);
        textFieldnumClass.setText("11");
        
        JLabel LabelParametri6 = new JLabel("Upper Bound Min Support", SwingConstants.RIGHT);
        LabelParametri6.setBounds(30, 245, 150, 20);
        jPanel1.add(LabelParametri6);
        
        textFieldupperBoundMinSupport = new JTextField();
        textFieldupperBoundMinSupport.setBounds(190, 240, 200, 30);
        jPanel1.add(textFieldupperBoundMinSupport);
        textFieldupperBoundMinSupport.setColumns(10);
        textFieldupperBoundMinSupport.setText("1.0");
        
        OutputTextArea = new JTextArea();        
        OutputScrollPane = new JScrollPane();
        OutputScrollPane.setBounds(30, 280, 600, 350);
        jPanel1.add(OutputScrollPane);
        OutputScrollPane.setViewportView(OutputTextArea);
        PrintStream printStream = new PrintStream(new ChurnOutput(OutputTextArea));
        
        AprioriButton = new JButton("Apriori");
        AprioriButton.setBounds(420, 240, 200, 30);
        jPanel1.add(AprioriButton);        
        AprioriButton.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		try {
        			weka.loadArff(selectedTestFile.toString());        			
        			double deltaValue = Double.parseDouble(textFieldDelta.getText());
        			double lowerBoundMinSupportValue = Double.parseDouble(textFieldlowerBoundMinSupport.getText());
        			double minMetricValue = Double.parseDouble(textFieldminMetric.getText());
        			int numRulesValue = Integer.parseInt(textFieldnumRules.getText());
        			int numClassValue = Integer.parseInt(textFieldnumClass.getText());
        			double upperBoundMinSupportValue = Double.parseDouble(textFieldupperBoundMinSupport.getText());
        			
        			weka.generateRule(deltaValue, lowerBoundMinSupportValue, minMetricValue, numRulesValue, numClassValue, upperBoundMinSupportValue);        			
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
        	}
        });
        
        System.setOut(printStream);
        System.setErr(printStream);
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
   
    
    private void initComponents() {
        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel1.setHorizontalAlignment(SwingConstants.CENTER);
        new javax.swing.JLabel();
        new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.HIDE_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(153, 153, 153));
        jPanel1.setLayout(null);

        jPanel2.setBackground(new java.awt.Color(204, 0, 0));

        jLabel1.setFont(new Font("Calibri", Font.BOLD, 18)); // NOI18N
        jLabel1.setText("APRIOR");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2Layout.setHorizontalGroup(
        	jPanel2Layout.createParallelGroup(Alignment.TRAILING)
        		.addGroup(Alignment.LEADING, jPanel2Layout.createSequentialGroup()
        			.addGap(306)
        			.addComponent(jLabel1, GroupLayout.PREFERRED_SIZE, 294, GroupLayout.PREFERRED_SIZE)
        			.addContainerGap(300, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
        	jPanel2Layout.createParallelGroup(Alignment.LEADING)
        		.addGroup(jPanel2Layout.createSequentialGroup()
        			.addContainerGap()
        			.addComponent(jLabel1, GroupLayout.PREFERRED_SIZE, 32, GroupLayout.PREFERRED_SIZE)
        			.addContainerGap(44, Short.MAX_VALUE))
        );
        jPanel2.setLayout(jPanel2Layout);

        jPanel1.add(jPanel2);
        jPanel2.setBounds(0, 0, 900, 40);

	    javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
	    layout.setHorizontalGroup(
	    	layout.createParallelGroup(Alignment.LEADING)
	    		.addComponent(jPanel1, GroupLayout.DEFAULT_SIZE, 900, Short.MAX_VALUE)
	    );
	    layout.setVerticalGroup(
	    	layout.createParallelGroup(Alignment.LEADING)
	    		.addGroup(layout.createSequentialGroup()
	    			.addComponent(jPanel1, GroupLayout.PREFERRED_SIZE, 675, GroupLayout.PREFERRED_SIZE)
	    			.addContainerGap(125, Short.MAX_VALUE))
	    );
	    getContentPane().setLayout(layout);
	
	    pack();
	    
	    Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
	    this.setLocation(dim.width/2-this.getSize().width/2, dim.height/2-this.getSize().height/2);
    }
    
    public static boolean exportTrainToCSV(JTable tableToExport,String pathToExportTo) {
        try {
            TableModel model = tableToExport.getModel();
            FileWriter csv = new FileWriter(new File(pathToExportTo));
            int i = 0;
            int j = 0;
            for (i = 0; i < (model.getColumnCount()-1); i++) {
                csv.write(model.getColumnName(i) + ",");
            }
            csv.write(model.getColumnName(i));
            csv.write("\n");
            for (i = 0; i < model.getRowCount()*0.4; i++) {
                for (j = 0; j < model.getColumnCount()-1; j++) {
                    csv.write(model.getValueAt(i, j).toString() + ",");
                }
                csv.write(model.getValueAt(i, j).toString());
                csv.write("\n");
            }

            csv.close();
            return true;
        } catch (IOException e) {
            e.printStackTrace();
        }
        return false;
    }
   
    public static boolean exportTestToCSV(JTable tableToExport,String pathToExportTo) {
        try {

            TableModel model = tableToExport.getModel();
            FileWriter csv = new FileWriter(new File(pathToExportTo));
            int i = 0;
            int j = 0;
            for (i = 0; i < (model.getColumnCount()-1); i++) {
                csv.write(model.getColumnName(i) + ",");
            }
            csv.write(model.getColumnName(i));
            csv.write("\n");
            for (i = (int) ((model.getRowCount()*0.4)+1); i < model.getRowCount(); i++) {
                for (j = 0; j < model.getColumnCount()-1; j++) {
                    csv.write(model.getValueAt(i, j).toString() + ",");
                }
                csv.write(model.getValueAt(i, j).toString());
                csv.write("\n");
            }

            csv.close();
            return true;
            
            
        } catch (IOException e) {
            e.printStackTrace();
        }
        return false;
    }
 
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ApriorForm3.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ApriorForm3.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ApriorForm3.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ApriorForm3.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Crea e visualizza il form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                
            	new ApriorForm3().setVisible(true);
            	//System.out.println("test");
            	
            }
        });
    }
    
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    
    private JButton AprioriButton;
    
    private JScrollPane OutputScrollPane;
    private JTextArea OutputTextArea;
    private JButton TestButton;
    
    private JTextArea textAreaTestFile;
    
    private JTextField textFieldDelta;
    private JTextField textFieldlowerBoundMinSupport;
    private JTextField textFieldminMetric;
    private JTextField textFieldnumRules;
    private JTextField textFieldnumClass;
    private JTextField textFieldupperBoundMinSupport;
}
