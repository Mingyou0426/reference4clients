import tkinter
from tkinter.filedialog import askopenfilename
import binascii

from os import path

from Cryptodome.Cipher import PKCS1_OAEP
from Cryptodome.PublicKey import RSA
from Cryptodome.Random import new as Random
from base64 import b64encode
from base64 import b64decode

pubkey = ''
prikey = ''
class RSA_Cipher:
  def generate_key(self,key_length):
    global pubkey
    global prikey
    if (path.isfile('./publickey.pem')):
        f = open('publickey.pem', 'rb')
        pubkey = RSA.importKey(f.read())
        f.close()
        f = open('privatekey.pem', 'rb')
        prikey = RSA.importKey(f.read())
        f.close()
    else:
        assert key_length in [1024,2048,4096]
        rng = Random().read
        # self.key = RSA.generate(key_length,rng)
        key = RSA.generate(key_length, rng)
        f = open('publickey.pem', 'wb')
        pubkey = key.publickey().exportKey()
        f.write(pubkey)
        f.close()
        f = open('privatekey.pem', 'wb')
        prikey = key.exportKey()
        f.write(prikey)
        f.close()

  def encrypt(self,data):
    plaintext = b64encode(data.encode())
    # plaintext = data
    # rsa_encryption_cipher = PKCS1_OAEP.new(self.key)
    rsa_encryption_cipher = PKCS1_OAEP.new(pubkey)
    ciphertext = rsa_encryption_cipher.encrypt(plaintext)
    return b64encode(ciphertext).decode()
    # return ciphertext

  def decrypt(self,data):
    ciphertext = b64decode(data.encode())
    # ciphertext = data
    # rsa_decryption_cipher = PKCS1_OAEP.new(self.key)
    rsa_decryption_cipher = PKCS1_OAEP.new(prikey)
    plaintext = rsa_decryption_cipher.decrypt(ciphertext)
    return b64decode(plaintext).decode()
    # return plaintext

top = tkinter.Tk()
top.title('Image Encryption using RSA')
top.resizable(0, 0)
top.geometry("700x320")

label1 = tkinter.Label(top, text ='Image file path: ')
label1.place(x=10, y=10, width=100, height=20)
# label1.pack()
imgpath = tkinter.Text(top)
imgpath.place(x=120, y=10, width=400, height=20)

label2 = tkinter.Label(top, text ='Cipher file path: ')
label2.place(x=10, y=40, width=100, height=20)
# label1.pack()
cippath = tkinter.Text(top)
cippath.place(x=120, y=40, width=400, height=20)

def startBrowse():
    global imgpath
    img_path = askopenfilename(filetypes=(("Image files", "*.bmp;*.jpeg;*.jpg;*.png"),
                                  ("All files", "*.*")))
    print(img_path)
    imgpath.delete("1.0", "end")
    imgpath.insert("1.0", img_path)

def startBrowse1():
    global cippath
    cip_path = askopenfilename(filetypes=(("Text files", "*.txt"),
                                  ("All files", "*.*")))
    print(cip_path)
    cippath.delete("1.0", "end")
    cippath.insert("1.0", cip_path)

browse = tkinter.Button(top, text = "Browse", command = startBrowse)
browse.place(x=550, y=10)

browse1 = tkinter.Button(top, text = "Browse", command = startBrowse1)
browse1.place(x=550, y=40)

cipher = RSA_Cipher()
print(cipher.generate_key(1024))

splitlen = 48
def startEncrypt():
    img_path = imgpath.get("1.0", "end")
    img_path = img_path[:-1]
    with open(img_path, 'rb') as f:
        content = f.read()
    f.close()
    result = binascii.hexlify(content)
    result = result.decode()
    i = 0
    f = open("Cipher.txt", "w")
    totlen = 0
    while (i<len(result)):
        subres = result[i:i+splitlen]
        subres = ''+subres
        enc = cipher.encrypt(subres)
        totlen = totlen+len(enc)
        f.write(enc)
        i = i+splitlen
    f.close()
    print('Encryption Finished. Please check "Cipher.txt"')

splitlen1 = 172
def startDecrypt():
    cip_path = cippath.get("1.0", "end")
    cip_path = cip_path[:-1]
    f = open(cip_path, "r")
    contents = f.read()
    i = 0
    result = ''
    while (i<len(contents)):
        subres = contents[i:i+splitlen1]
        dec = cipher.decrypt(subres)
        result = result+dec
        i = i+splitlen1
    f.close()
    contents = bytearray.fromhex(result)
    f = open('2.png', 'wb')
    f.write(contents)
    f.close()
    print('Decryption Finished. Please check "2.png"')

encsta = tkinter.Button(top, text = "Encrypt", command = startEncrypt)
encsta.place(x=600, y=10)

decsta = tkinter.Button(top, text = "Decrypt", command = startDecrypt)
decsta.place(x=600, y=40)

top.mainloop()