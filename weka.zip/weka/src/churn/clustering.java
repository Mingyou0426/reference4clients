package churn;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.Scanner;

import com.mysql.jdbc.jdbc2.optional.MysqlDataSource;

import weka.clusterers.ClusterEvaluation;
import weka.clusterers.HierarchicalClusterer;
import weka.clusterers.SimpleKMeans;
import weka.core.Instances;
import weka.filters.Filter;
import weka.filters.unsupervised.attribute.Remove;
import weka.core.EuclideanDistance;
import weka.core.converters.ConverterUtils.DataSource;
import weka.filters.unsupervised.attribute.AddCluster;

public class clustering {
	public static int [] clusterids;
	public static Connection getConnection() {
	    Connection con = null;
	    
        MysqlDataSource mds = new MysqlDataSource();
        
        mds.setServerName("localhost");
        mds.setPortNumber(3306);
        mds.setUser("root");
        mds.setPassword("root");
        mds.setDatabaseName("retention");
        
        try {
            con = mds.getConnection();
        } catch(SQLException ex){
            System.out.println(ex.getMessage());
        }
        
        return con;
    }
	
	public static void clustering(File trainfile, File testfile, int numcluster, int evalue)throws Exception 
	{
		int i;
		String[] headers = null;
		Scanner scanner = new Scanner(trainfile);

		if (scanner.hasNextLine())
		    headers = scanner.nextLine().split(",");
		scanner.close();
		
		ArrayList<File> listOfFilesToBeMerged = new ArrayList<File>();
		listOfFilesToBeMerged.add(trainfile);
		listOfFilesToBeMerged.add(testfile);
		Iterator<File> iterFiles = listOfFilesToBeMerged.iterator();
		File destFile = new File("mergedFile.csv");
		BufferedWriter writer = new BufferedWriter(new FileWriter(destFile));

		boolean flag = false;
		while (iterFiles.hasNext()) {
		  File nextFile = iterFiles.next();
		  BufferedReader reader = new BufferedReader(new FileReader(nextFile));

		  String line = null;
		  String[] firstLine = null;
		  if ((line = reader.readLine()) != null)
		    firstLine = line.split(",");

		  if (!Arrays.equals (headers, firstLine))
		    throw new Exception("Header mis-match between CSV files: '" +
		    		trainfile + "' and '" + nextFile.getAbsolutePath());

		  if ( !flag ) {
			  writer.write(line);
			  writer.newLine();
			  flag = true;
		  }
		  while ((line = reader.readLine()) != null) {
		    writer.write(line);
		    writer.newLine();
		  }

		  reader.close();
		}
		writer.close();
		
		DataSource source = new DataSource(destFile.toString());
		Instances dest = source.getDataSet();
				
		Remove filter = new Remove();
		filter.setAttributeIndices("1");
		filter.setInputFormat(dest);
		
		Instances newData = Filter.useFilter(dest, filter);
		
		SimpleKMeans clusterer = new SimpleKMeans();
		clusterer.setNumClusters(numcluster);
		clusterer.buildClusterer(newData); 
		
		ClusterEvaluation eval = new ClusterEvaluation();
		eval.setClusterer(clusterer); 
		eval.evaluateClusterer(new Instances(dest));

		String msgs = eval.clusterResultsToString();
		
		msgs = msgs.substring(0, msgs.indexOf("Clustered"));
		System.out.println(msgs);
		
		if ( evalue==0 ) {		
			FileWriter writer1 = new FileWriter("datasetok-output.csv");
			writer1.append("cid");
			writer1.append(',');
			writer1.append("Sesso");
			writer1.append(',');
			writer1.append("etacliente");
			writer1.append(',');
//			writer1.append("AgeMese");
			writer1.append("AttivoDA");
			writer1.append(',');
//			writer1.append("TT");
			writer1.append("Guasti");
			writer1.append(',');
//			writer1.append("Reclami");
			writer1.append("RecAmm");
			writer1.append(',');
//			writer1.append("TotaleGR"); // removed
//			writer1.append(',');
//			writer1.append("NCC");
			writer1.append("numContatti");
			writer1.append(',');
			writer1.append("Linea");
			writer1.append(',');
			writer1.append("mobile");
			writer1.append(',');
			writer1.append("Tecnologia");
			writer1.append(',');
			writer1.append("MotivoDisdetta");
			writer1.append(',');
//			writer1.append("SpesaMensileCliente");
//			writer1.append(',');
			writer1.append("costoservizio");
			writer1.append(',');
			writer1.append("cluster");
			writer1.append('\n');
			
			Connection con = getConnection();
			Statement stmt = con.createStatement();
			String query = "delete from dataset";
			stmt.executeUpdate(query);
		
			int clust = 0;
			for (i=0; i < newData.numInstances();i++) {
				System.out.print("Instance ");
				System.out.print(i);
				System.out.print("\tEstimated Class: ");
				try {
					clust=clusterer.clusterInstance(newData.instance(i));
					System.out.println(clust);
				}
				catch (Exception ex){
					System.out.print("Pattern not assigned!!");
				}
				
				writer1.append(dest.instance(i).stringValue(0));
				writer1.append(',');
				writer1.append(dest.instance(i).stringValue(1));
				writer1.append(',');
				writer1.append(dest.instance(i).stringValue(2));
				writer1.append(',');
				writer1.append(String.valueOf((int)dest.instance(i).value(3)));
				writer1.append(',');
				writer1.append(String.valueOf((int)dest.instance(i).value(4)));
				writer1.append(',');
				writer1.append(String.valueOf((int)dest.instance(i).value(5)));
				writer1.append(',');
				writer1.append(String.valueOf((int)dest.instance(i).value(6)));
				writer1.append(',');
				writer1.append(dest.instance(i).stringValue(7));
				writer1.append(',');
				writer1.append(dest.instance(i).stringValue(8));
				writer1.append(',');
				writer1.append(dest.instance(i).stringValue(9));
				writer1.append(',');
				writer1.append(dest.instance(i).stringValue(10));
				writer1.append(',');
				writer1.append(newData.instance(i).stringValue(10));
				writer1.append(',');
				writer1.append("cluster"+String.valueOf(clusterids[clust]));
				writer1.append(',');
				writer1.append('\n');
				
				query = "insert into dataset(cid, s, eta, att, gua, rec, numc, linea, mob, tecno, md, cm, cluster)"
						+ "values('" + dest.instance(i).stringValue(0) + "', '" + dest.instance(i).stringValue(1) + "', '"+dest.instance(i).stringValue(2)
						+ "', " + (int)dest.instance(i).value(3) + ", " + (int)dest.instance(i).value(4) + ", "
						+ (int)dest.instance(i).value(5) + ", " + (int)dest.instance(i).value(6) + ", '" + dest.instance(i).stringValue(7) + "', '"
						+ dest.instance(i).stringValue(8) + "', '" + dest.instance(i).stringValue(9)
						+ "', '" + dest.instance(i).stringValue(10) + "', '" + newData.instance(i).stringValue(10)
						+ "', '" + "cluster"+String.valueOf(clusterids[clust]) +"')";
				stmt.executeUpdate(query);
			}
			
			if ( stmt!=null ) stmt.close();
			if ( con!=null ) con.close();
			
			writer1.flush();
			writer1.close();
		}
	}
}
