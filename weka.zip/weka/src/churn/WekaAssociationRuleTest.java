package churn;

import weka.associations.Apriori;
import weka.core.Instances;
import weka.core.converters.ConverterUtils.DataSource;

public class WekaAssociationRuleTest {
	Instances superMarket = null;
	Apriori apriori;
	public void loadArff(String arffInput){
		DataSource source = null;
		try {
			source = new DataSource(arffInput);
			superMarket = source.getDataSet();
		} catch (Exception e1) {
		}
	}
	public void generateRule(double deltaValue, double lowerBoundMinSupportValue, double minMetricValue
			, int numRulesValue, int numClassValue, double upperBoundMinSupportValue){
//		double deltaValue = 0.05; 
//		double lowerBoundMinSupportValue = 0.3; 
//		double minMetricValue = 0.5; 
//		int numRulesValue = 10; 
//		int numClassValue = 11;
//		double upperBoundMinSupportValue = 1.0;
		
		apriori = new Apriori();
		try {
			
			apriori.setClassIndex(numClassValue);
			apriori.setDelta(deltaValue); 
			apriori.setLowerBoundMinSupport(lowerBoundMinSupportValue); 
			apriori.setNumRules(numRulesValue); 
			apriori.setUpperBoundMinSupport(upperBoundMinSupportValue); 
			apriori.setMinMetric(minMetricValue);
			apriori.buildAssociations(superMarket);
			System.out.println(apriori);
		} catch (Exception e) {
		}
	}
//	
//	public static void main(String args[]){
//		WekaAssociationRuleTest test = new WekaAssociationRuleTest();
//		test.loadArff("datasetCategorico.arff");
//		test.generateRule();
//	}
}
